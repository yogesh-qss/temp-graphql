const Constants = require('../utils/constants');

module.exports = (sequelize, DataTypes) => {
  let User = sequelize.define("User", {
      id: {
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER,
      },
      keyCloakUserId: { type: DataTypes.STRING, defaultValue: null },
      status: { type: DataTypes.INTEGER, defaultValue: Constants.STATUS.ACTIVE },
    },
    {
      paranoid: true,
      underscored: true,
      tableName: "users",
    }
  );

  User.associate = (models) => {
    User.belongsTo(models.User, { foreignKey: 'accountId', as: 'Account' });
  }
  
  return User;
};  
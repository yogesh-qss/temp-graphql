const apolloServerExpress = require('apollo-server-express');

module.exports = apolloServerExpress.gql`
  type Token {
    user: User!
    refreshToken: String
    accessToken: String
  }

  extend type Query {
    
  }

  extend type Mutation {
    
  }
`
const apolloServerExpress = require('apollo-server-express');

module.exports = apolloServerExpress.gql`
  type Token {
    user: User!
    refreshToken: String
    accessToken: String
  }

  type User {
    id: ID!
    email: String!
    lastName: String
    firstName: String!
  }

  type SignUpResponse {
    message: String!
    token: String
  }

  type VerifyCodeResponse {
    message: String!
    data: Token!
  }

  extend type Query {
    users: [User!]
    user(id: ID!): User
  }

  extend type Mutation {
    createUser(
      firstName: String!
      lastName: String!
      email: String!
      password: String!
    ): User!
    
    signUp(
      firstName: String!
      lastName: String!
      email: String!
      password: String!
    ): SignUpResponse!

    verifyCode(
      token: String!
      code: String!
      verificationType: String!
    ): VerifyCodeResponse!

    login(
      email: String!, 
      password: String!
    ): User!
  }
`
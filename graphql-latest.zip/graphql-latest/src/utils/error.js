const apolloServerExpress = require('apollo-server-express');

module.exports = {
    badRequestError: (errorMessage) => {
        return new apolloServerExpress.ValidationError(errorMessage)
    },

    userValidationError: (error) => {
        return new apolloServerExpress.UserInputError('USER_INPUT_ERROR', {
            validationErrors: error.details
        })
    },

    authenticationError: (errorMessage) => {
        return new apolloServerExpress.AuthenticationError(errorMessage)
    },

    authorizationError: (errorMessage) => {
        return new apolloServerExpress.ForbiddenError(errorMessage)
    },

    internalServerError: (error) => {
        return new apolloServerExpress.ApolloError(error.message, {
            extensions: {
                code: 'INTERNAL_SERVER_ERROR',
            }
        })
    },
}
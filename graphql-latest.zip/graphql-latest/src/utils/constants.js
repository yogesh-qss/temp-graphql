module.exports = {
    KEYCLOAK_ENDPOINT: {
        AUTH: '/protocol/openid-connect/token'
    },
    STATUS: {
        ACTIVE: 1,
        INACTIVE: 0,
    }
}
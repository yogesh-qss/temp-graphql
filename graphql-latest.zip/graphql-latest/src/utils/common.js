const crypto = require('crypto');
const moment = require('moment');
const jwt = require('jsonwebtoken');

global.encrypt = (text) => {
    let cipher = crypto.createCipheriv(
        process.env.ALGORITHM, 
        process.env.PRIVATE_KEY, 
        process.env.IV
    );
    return cipher.update(text, "utf8", "hex") + cipher.final("hex");
}

global.decrypt = (text) => {
    let decipher = crypto.createDecipheriv(
        process.env.ALGORITHM, 
        process.env.PRIVATE_KEY, 
        process.env.IV
    );
    return decipher.update(text, "hex", "utf8") + decipher.final("utf8");
}

module.exports = {
    signToken: (tokenData, expiresIn) => {
        return jwt.sign(
          { data: encrypt(JSON.stringify(tokenData))},
          process.env.PRIVATE_KEY,
          { expiresIn: expiresIn }
        );
    },

    validateToken: async (token) => {
        let decryptedToken = JSON.parse(decrypt(token.data));
        const expiryTime = moment(token.exp * 1000);
        if (expiryTime > moment()) {
            return {
                isValid: true,
                credentials: { userData: decryptedToken, scope: decryptedToken?.permissions }
            };
        }
        return {
            isValid: false
        };
    },

    axiosRequest: async (requestUrl,requestMethod,requestHeader,requestBody) => {
        try {
            let responseData;
            let requestObject = {
                url: requestUrl,
                headers: requestHeader,
                method: requestMethod.toLowerCase(),
            }
            requestObject = (requestMethod.toLowerCase() === 'get') ? {...requestObject,params:requestBody} : {...requestObject,data:requestBody}
            responseData = await Axios(requestObject);
            responseData = responseData.data;
            return responseData;
        } catch({response}) {
            return response ? response.data : 'AXIOS_REQUEST_FAILED';
        }
    },

    generateCode: (requestedLength) => {
        if(process.env.MASTER_CODE_ENABLED) {
            return process.env.MASTER_CODE;
        } else {
            const characters = '1234567890';
            const length = typeof requestedLength != 'undefined' ? requestedLength : 4;
            let randomValue = '';
            for (let i = 0; i < length; i++) {
                const value = Math.floor(Math.random() * characters.length);
                randomValue += characters.substring(value, value + 1).toUpperCase();
            }
            return randomValue;
        }
    }
}
const graphqlISODate = require('graphql-iso-date');

const userResolver = require('./user');

const customScalarResolver = {
  Date: graphqlISODate.GraphQLDateTime,
};

module.exports = [ customScalarResolver, userResolver ]
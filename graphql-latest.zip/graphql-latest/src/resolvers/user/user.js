const joi = require('joi');
const moment = require('moment');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const common = require('../../utils/common');
const customError = require('../../utils/error');
const constants = require('../../utils/constants');

const signUpValidations = async (requestBody) => {
  const joiSchema = joi.object({
    phoneNumber: joi.string().length(10).required(),
    password: joi.string().min(8).max(20).required(),
    signUpType: joi.string().valid('registration').required(),
    countryCode: joi.string().min(1).max(5).required().default('+1'),
    confirmPassword: joi.any().valid(joi.ref('password')).required(),
    email: joi.string().pattern(new RegExp('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$')).required(),
  })
  return joiSchema.validate(requestBody)
}

const verifyCodeValidations = async (requestBody) => {
  const joiSchema = joi.object({
    token: joi.string().required(),
    code: joi.string().length(4).required(),
    verificationType: joi.string().alphanum().min(3).max(30).required(),
  })
  return joiSchema.validate(requestBody)
}

const loginAction = async (user) => {
  let hasFullAccess = constants.STATUS.ACTIVE;
  let responseData = {user,hasFullAccess}

  const accessTokenData = responseData;
  let accessToken = common.signToken(accessTokenData,process.env.ACCESS_TOKEN_EXPIRE_TIME);

  let refreshTokenData = {userId:user.id,timestamp:moment().valueOf()};
  let refreshToken = await generateRefreshToken(refreshTokenData);

  responseData = {...responseData,accessToken,refreshToken};
  return responseData;
}

const generateRefreshToken = async (data) => {
  let tokenVersion = constants.REFRESH_TOKEN.VERSION.V1;
  let refreshToken = encrypt(JSON.stringify(data));
  return `${tokenVersion}_${refreshToken}`;
}

module.exports =  {
  Query: {
    users: async (parent, args, { models }) => {
      return await models.User.findAll({});
    },
    user: async (parent, { id }, { models }) => {
      return await models.User.findOne({ where: { id } });
    },
  },

  Mutation: {
    signUp: async (parent, requestBody, { models }) => {
      const transaction = await models.sequelize.transaction();
      try {
        const { _, error } = await signUpValidations(requestBody);
        if(error) {
          throw customError.userValidationError(error);
        }

        const { email, countryCode, phoneNumber, password, signUpType } = requestBody;

        switch(signUpType) {
          case 'registration':

            break;
          default:
            await transaction.rollback();
            return customError.badRequestError('Invalid sign up type provided');
        }
        
        await transaction.commit();
        return {
          token: token,
          message: 'VERIFICATION_CODE_HAS_BEEN_SENT_SUCCESSFULLY',
        }
      } catch(error) {
        console.log(error);
        await transaction.rollback();
        throw customError.internalServerError(error);
      }
    },

    verifyCode: async (parent, requestBody, { models }) => {
      const transaction = await models.sequelize.transaction();
      try {
        const { _, error } = await verifyCodeValidations(requestBody);
        if(error) {
          await transaction.rollback();
          return customError.userValidationError(error);
        }

        const {token,code,verificationType} = requestBody;

        let tokenExists = await models.Token.findOne({where:{token,code,status:constants.STATUS.ACTIVE}});
        if(!tokenExists) {
          await transaction.rollback();
          return customError.badRequestError('Token expired or invalid code');
        }

        let tokenValidated = await common.validateToken(jwt.decode(token));
        if(!tokenValidated?.isValid) {
          await transaction.rollback();
          return customError.badRequestError('Token expired');
        }

        let userData = tokenValidated?.credentials?.userData;
        switch(verificationType) {
          case 'signup':
            const rounds = parseInt(process.env.HASH_ROUNDS);
            let userPassword = bcrypt.hashSync(userData?.password,rounds);

            let createdUser = await models.User.create({
              email: userData?.email,
              password: userPassword,
              lastName: userData?.lastName,
              firstName: userData?.firstName,
            },{transaction:transaction});

            await tokenExists.update({status:constants.STATUS.INACTIVE,userId:createdUser.id},{transaction:transaction});

            let maskedPassword = "*".repeat(userData.password.length);
            createdUser.password = maskedPassword;

            let responseData = await loginAction(createdUser);

            const userId = createdUser?.id;
            await models.Auth.destroy({where:{userId}},{transaction:transaction});
            if(userId) await models.Auth.create({userId,refreshToken:responseData?.refreshToken},{transaction:transaction});

            await transaction.commit();
            return {
              data: responseData,
              message: 'USER_VERIFIED_SUCCESSFULLY',
            }

          default:
            await transaction.rollback();
            return customError.badRequestError('Invalid verification type');
        }
      } catch(error) {
        console.log(error);
        await transaction.rollback();
        throw customError.internalServerError(error);
      }
    },
  }
};

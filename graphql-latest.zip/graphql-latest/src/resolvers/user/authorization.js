const apolloServer = require('apollo-server');
const graphqlResolver = require('graphql-resolvers');

module.exports = {
    generateAccessToken: async (keycloakDomain, keycloakEndpoint, username, password) => {
        let requestHeaders = {
            'Accept': 'application/x-www-form-urlencoded',
            'Content-Type': 'application/x-www-form-urlencoded',
        }
        let requestBody = {
            client_id: process.env.KEYCLOAK_CLIENT_ID
        }

        if(username !== null && password !== null) {
            requestBody = {
                ...requestBody, username, password,
                grant_type: process.env.KEYCLOAK_PASSWORD_GRANT_TYPE
            }
        } else {
            requestBody = {
                ...requestBody,
                client_secret: process.env.KEYCLOAK_CLIENT_SECRET,
                grant_type: process.env.KEYCLOAK_ACCESS_GRANT_TYPE,
            }
        }
        
        this.axiosRequest()
        return new Promise(async (resolve, reject) => {
            let options = userName != null && userPassword != null?  {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Accept': 'application/x-www-form-urlencoded'
                },
                body: `grant_type=${process.env.KEYCLOAK_GRANT_TYPE}&username=${userName}&password=${userPassword}&client_id=${process.env.KEYCLOAK_CLIENT_ID}`
            } : {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Accept': 'application/x-www-form-urlencoded'
                },
                body: `grant_type=${process.env.KEYCLOAK_ACCESS_GRANT_TYPE}&client_id=${process.env.KEYCLOAK_ACCESS_CLIENT_ID}&client_secret=${process.env.KEYCLOAK_ACCESS_CLIENT_SECRET}`  
            }
            console.log("optionsoptions",options)
            // keyclock Api calling
            let fetchRes = fetch(
                `${keyCloakUrl}/protocol/openid-connect/token`,
                options);
            fetchRes.then(res =>
                res.json()).then(keyCloakData => {
                    console.log("keyCloakDatakeyCloakData",keyCloakData)
                    if (keyCloakData != "" || keyCloakData != undefined) {
                        if(keyCloakData.error){
                            return resolve({ "status": 201, "access_token": keyCloakData.access_token, "access_token_expires_in": keyCloakData.expires_in, "refresh_expires_in": keyCloakData.refresh_expires_in, "refresh_token": keyCloakData.refresh_token })
                        }else{
                            return resolve({ "status": 200, "access_token": keyCloakData.access_token, "access_token_expires_in": keyCloakData.expires_in, "refresh_expires_in": keyCloakData.refresh_expires_in, "refresh_token": keyCloakData.refresh_token })
                        }
                    }
                    else {
                        return resolve({ "status": 201, "access_token": "" })
                    }
                })
        })
    },
}
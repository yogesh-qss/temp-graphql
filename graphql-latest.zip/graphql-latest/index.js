require("dotenv").config();
const cors = require('cors');
const morgan = require('morgan');
const express = require('express');
const apolloServerExpress = require('apollo-server-express');

const models = require('./src/model');
const common = require('./src/utils/common');
const typeDefs = require('./src/schema/index');
const customError = require('./src/utils/error');
const resolvers = require('./src/resolvers/index');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(morgan('dev'));

const getUserDetails = async (req) => {
  const token = req.headers.authorization;
  if (token) {
    try {
      return common.validateToken(token);
    } catch(error) {
      console.log(error)
      throw customError.validationError(error?.message)
    }
  }
};

const server = new apolloServerExpress.ApolloServer({
  typeDefs,
  resolvers,
  introspection: true,
  playground: {
    settings: {
      "schema.polling.enable": false,
    }
  },
  context: async ({ req, connection }) => {
      const user = await getUserDetails(req);
      return {user, models};
  },
});

server.applyMiddleware({ app, path: '/graphql' });

init = async () => {
  await models.sequelize.authenticate();
  await models.sequelize.sync().then(() => {
    app.listen(PORT, () => {
      console.log(`Listening on port ${PORT}...`);
    });
  });
}

init();
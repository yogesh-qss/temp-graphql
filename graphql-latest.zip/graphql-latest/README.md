# Graphql setup

Setting up graphql structure for the application

## Technology stack

> Backend: Node.js
>
> Database: MySQL
>
> Version Control: Git & Github
const joi = require('joi');

const customError = require('../../utils/error');
const {
    getKeycloakUsers,
    createKeycloakUser,
    resetKeycloakUserPassword,
    generateKeycloakAccessToken
 } = require('../../utils/keycloakService');


const signUpValidations = async (requestBody) => {
    const joiSchema = joi.object({
      phoneNumber: joi.string().length(10).required(),
      password: joi.string().min(8).max(20).required(),
      signUpType: joi.string().valid('registration').required(),
      countryCode: joi.string().min(1).max(5).required().default('+1'),
      confirmPassword: joi.any().valid(joi.ref('password')).required(),
      email: joi.string().pattern(new RegExp('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$')).required(),
    })
    return joiSchema.validate(requestBody)
}

const loginValidations = async (requestBody) => {
    const joiSchema = joi.object({
      password: joi.string().min(8).max(20).required(),
      email: joi.string().pattern(new RegExp('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$')).required(),
    })
    return joiSchema.validate(requestBody)
}

module.exports = {
    Query: {

    }, 

    Mutation: {
        login: async (parent, requestBody, { models }) => {
            try {
                const { _, error } = await loginValidations(requestBody);
                if (error) {
                    return customError.userValidationError(error?.message, JSON.stringify(error?.details));
                }

                const { email, password } = requestBody;

                let userAccessToken = await generateKeycloakAccessToken(email, password)
                if (userAccessToken.error) {
                    return userAccessToken.error;
                }

                userAccessToken = userAccessToken?.data?.responseData;

                const userExists = await models.User.findOne({where: {email}})

                return {
                    status: 200,
                    message: 'Successfully logged in!',
                    data: {
                        user: userExists,
                        expiresIn: userAccessToken?.expires_in,
                        tokenType: userAccessToken?.token_type,
                        accessToken: userAccessToken?.access_token,
                        refreshToken: userAccessToken?.refresh_token,
                        refreshExpiresIn: userAccessToken?.refresh_expires_in,
                    }
                }

            } catch(error) {
                console.log(error);
                return customError.internalServerError(error);
            }
        },

        signUp: async (parent, requestBody, { models }) => {
            const transaction = await models.sequelize.transaction();
            try {
                // Joi Validations for signup!
                const { _, error } = await signUpValidations(requestBody);
                if (error) {
                    await transaction.rollback();
                    return customError.userValidationError(error?.message, JSON.stringify(error?.details));
                }
        
                const { email, countryCode, phoneNumber, password, signUpType } = requestBody;
        
                // Handling all possible signup scenarios
                switch(signUpType) {
                    case 'registration':
                        // Generate access token using admin credentials to onboard new user
                        let generatedKeycloakAccessToken = await generateKeycloakAccessToken(process.env.KEYCLOAK_USERNAME, process.env.KEYCLOAK_PASSWORD)
                        if (generatedKeycloakAccessToken.error) {
                            await transaction.rollback();
                            return generatedKeycloakAccessToken.error;
                        }
                        
                        // Checking if the access token was generated successfully or not
                        generatedKeycloakAccessToken = generatedKeycloakAccessToken?.data?.responseData;
                        const accessToken = generatedKeycloakAccessToken?.access_token;
                        if (!accessToken) {
                            await transaction.rollback();
                            return customError.badRequestError('Unable to fetch access token from keycloak')
                        }


                        // // Checking if users with the provided username already exists in the keycload database
                        // Fetching all the users by putting username as the filter
                        let fetchedKeycloakUsers = await getKeycloakUsers(accessToken, email);
                        if (fetchedKeycloakUsers.error) {
                            await transaction.rollback();
                            return fetchedKeycloakUsers.error;
                        }

                        // Checking if a user exists with the provided username
                        if (fetchedKeycloakUsers?.data?.responseData.length > 0) {
                            await transaction.rollback();
                            return customError.conflictError('User with provided email ID already exists. Please try using different email ID')
                        }


                        // Create user with default configurations
                        let keycloakUserDetails = {
                            username: email,
                            email: email.toLowerCase(),
                        }
                        let createdKeycloakUser = await createKeycloakUser(accessToken, keycloakUserDetails)
                        if (createdKeycloakUser.error) {
                            await transaction.rollback();
                            return createdKeycloakUser.error;
                        }

                        // Once use created, set the password for the user
                        let newKeycloakUser = await getKeycloakUsers(accessToken, email);
                        const keycloakUserId = newKeycloakUser?.data?.responseData?.[0].id;
                        const passwordUpdated = await resetKeycloakUserPassword(accessToken, keycloakUserId, password)
                        if (passwordUpdated.error) {
                            await transaction.rollback();
                            return passwordUpdated.error;
                        }

                        // TODO: Create user in the local database and store the keycloak user id the local database
                        await models.User.create({
                            username: email,
                            keycloakUserId, email, phoneNumber, countryCode, signUpType,
                        }, {transaction:transaction});

                        // Generate new access tokens for signed up user
                        let generatedKeycloakAccessTokenForNewUser = await generateKeycloakAccessToken(email, password)
                        if(generatedKeycloakAccessTokenForNewUser.error) {
                            await transaction.rollback();
                            return generatedKeycloakAccessTokenForNewUser.error;
                        }
                        generatedKeycloakAccessTokenForNewUser = generatedKeycloakAccessTokenForNewUser?.data?.responseData;

                        await transaction.commit();
                        return {
                            status: 200,
                            message: 'Successfully signed up!',
                            data: {
                                expiresIn: generatedKeycloakAccessTokenForNewUser.expires_in,
                                tokenType: generatedKeycloakAccessTokenForNewUser.token_type,
                                accessToken: generatedKeycloakAccessTokenForNewUser.access_token,
                                refreshToken: generatedKeycloakAccessTokenForNewUser.refresh_token,
                                refreshExpiresIn: generatedKeycloakAccessTokenForNewUser.refresh_expires_in,
                            }
                        }

                    default:
                        await transaction.rollback();
                        return customError.badRequestError('Invalid sign up type provided');
                }
            } catch(error) {
                console.log(error);
                await transaction.rollback();
                return customError.internalServerError(error);
            }
        },
    }
}

const graphqlISODate = require('graphql-iso-date');

const authorizationResolver = require('./user/authorization');

const customScalarResolver = {
  Date: graphqlISODate.GraphQLDateTime,
};

module.exports = [ customScalarResolver, authorizationResolver ]
const apolloServerExpress = require('apollo-server-express');

module.exports = apolloServerExpress.gql`
  type SignUpResponse {
    status: Int!
    message: String!
    data: KeycloakAuthResponse
    error: KeycloakAuthError
  }

  type LoginResponse {
    status: Int!
    message: String!
    data: KeycloakAuthResponse
    error: KeycloakAuthError
  }

  type KeycloakAuthResponse {
    user: User
    accessToken: String!
    expiresIn: Int!
    refreshToken: String!
    refreshExpiresIn: Int!
    tokenType: String!
  }

  type User {
    firstName: String
    lastName: String
    dob: Date
    gender: String
    isEmailVerified: Boolean!
    email: String
    countryCode: String
    phoneNumber: String
    createdAt: Date
    isPhoneNumberVerified: Boolean!
    isAccountVerified: Boolean!
    isProfileUpdated: Boolean!
    status: Int!
    identityType: String!
  }

  type KeycloakAuthError {
    error: String!
    errorDescription: String
  }

  extend type Mutation {
    signUp(
      email: String!
      password: String!
      signUpType: String!
      countryCode: String!
      phoneNumber: String!
      confirmPassword: String!
    ): SignUpResponse!

    login(
      email: String!
      password: String!
    ): LoginResponse!
  }
`
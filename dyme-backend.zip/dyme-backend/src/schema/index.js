const apolloServerExpress = require('apollo-server-express');

const userAuthorizationSchema = require('./user/authorization');

const baseSchema = apolloServerExpress.gql`
  scalar Date

  type Query {
    _: Boolean
  }

  type Mutation {
    _: Boolean
  }

  type Subscription {
    _: Boolean
  }
`

module.exports = [ baseSchema, userAuthorizationSchema ]
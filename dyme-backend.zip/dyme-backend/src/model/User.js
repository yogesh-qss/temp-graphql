const constants = require('../utils/constants');

module.exports = (sequelize, DataTypes) => {
  let User = sequelize.define("User", {
      id: {
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER,
      },
      dob: { type: DataTypes.DATE, defaultValue: null },
      email: { type: DataTypes.STRING, allowNull: false },
      gender: { type: DataTypes.STRING, defaultValue: null },
      signUpType: { type: DataTypes.STRING, allowNull: false },
      lastName: { type: DataTypes.STRING, defaultValue: null },
      firstName: { type: DataTypes.STRING, defaultValue: null },
      username: { type: DataTypes.STRING, defaultValue: null },
      phoneNumber: { type: DataTypes.STRING, allowNull: false },
      countryCode: { type: DataTypes.STRING, defaultValue: '+1' },
      keyCloakUserId: { type: DataTypes.STRING, defaultValue: null },
      isEmailVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
      isProfileUpdated: { type: DataTypes.BOOLEAN, defaultValue: false },
      isAccountVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
      isPhoneNumberVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
      status: { type: DataTypes.INTEGER, defaultValue: constants.STATUS.ACTIVE },
      roleId: { type: DataTypes.INTEGER, defaultValue: constants.DEFAULT_ROLES.USER },
      identityType: { type: DataTypes.STRING, defaultValue: constants.USER_IDENTITY.INDIVIDUAL },
    },
    {
      paranoid: true,
      underscored: true,
      tableName: "users",
    }
  );

  User.associate = (models) => {
  }
  
  return User;
};  
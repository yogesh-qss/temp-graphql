const aws = require('aws-sdk');

const constants = require('./constants');

const sns = new aws.SNS({
    region: process.env.SNS_REGION,
    apiVersion: process.env.SNS_API_VERSION,
    accessKeyId: process.env.SNS_ACCESS_KEY_ID,
    secretAccessKey: process.env.SNS_SECRET_ACCESS_KEY,
});


const sendSMS = async (phoneNumber, message, smsType=constants.SMS_TYPES.TRANSACTIONAL) => {
    sns.publish({
        Message: message,
        PhoneNumber: phoneNumber,
        MessageAttributes: {
            'AWS.SNS.SMS.SMSType': {
                DataType: 'String',
                StringValue: smsType,                                                                //  Needs to be changes based on requirements
            }
        }
    }, (error, data) => {
        if (error) return {data: null, error}
        console.log('//////////////////////////////////////')
        console.log('SMS_SENT: ', data)
        console.log('//////////////////////////////////////')
        return {data, error: null}
    })
}

module.exports = {
    sendSMS,
}
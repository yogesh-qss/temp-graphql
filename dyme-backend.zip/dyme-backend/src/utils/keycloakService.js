const common = require('./common');
const customError = require('./error');
const constants = require('./constants');


const generateKeycloakAccessToken =  async (username=null, password=null) => {
    let requestHeaders = {
        'Accept': 'application/x-www-form-urlencoded',
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    let requestBody = {
        client_id: process.env.KEYCLOAK_CLIENT_ID
    }

    if(username !== null && password !== null) {
        requestBody = {
            ...requestBody, username, password,
            grant_type: process.env.KEYCLOAK_PASSWORD_GRANT_TYPE
        }
    } else {
        requestBody = {
            ...requestBody,
            client_secret: process.env.KEYCLOAK_CLIENT_SECRET,
            grant_type: process.env.KEYCLOAK_ACCESS_GRANT_TYPE,
        }
    }
    
    const keycloakAuthUrl = `${process.env.KEYCLOAK_AUTH_API_DOMAIN}${constants.KEYCLOAK_ENDPOINT.AUTH}`;

    const keycloakAuthResponse = await common.axiosRequest(keycloakAuthUrl, 'POST', requestHeaders, requestBody);
    if (keycloakAuthResponse.status !== 200) {
        return {
            data: null, 
            error: customError.unknownError(
                keycloakAuthResponse.status,
                keycloakAuthResponse?.responseData?.error, 
                keycloakAuthResponse?.responseData?.error_description)
            }
    }

    return {data: keycloakAuthResponse, error: null};
}

const getKeycloakUsers = async (accessToken, username=null) => {
    let requestBody = {}
    let requestHeaders = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
    }
    
    let keycloakGetUsersUrl = `${process.env.KEYCLOAK_API_DOMAIN}${constants.KEYCLOAK_ENDPOINT.GET_USERS}`;
    if (username !== null) {
        keycloakGetUsersUrl = `${keycloakGetUsersUrl}?username=${username}`;
    };
    
    let keycloakGetUsersResponse =  await common.axiosRequest(keycloakGetUsersUrl, 'GET', requestHeaders, requestBody);
    if (keycloakGetUsersResponse.status !== 200) {
        return {
            data: null, 
            error: customError.unknownError(
                keycloakGetUsersResponse.status, 
                keycloakGetUsersResponse?.responseData?.error, 
                keycloakGetUsersResponse?.responseData?.error_description)
            }
    }

    return {data: keycloakGetUsersResponse, error: null};
}

const createKeycloakUser = async (accessToken, userDetails) => {
    let requestBody = {
        ...userDetails,
        groups: [],
        lastName: '',
        firstName: '',
        enabled: true,
        emailVerified: true,
        requiredActions: [],
    };
    let requestHeaders = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
    }
    
    let keycloadAddUserUrl = `${process.env.KEYCLOAK_API_DOMAIN}${constants.KEYCLOAK_ENDPOINT.ADD_USER}`;

    let keycloakCreateUserResponse = await common.axiosRequest(keycloadAddUserUrl, 'POST', requestHeaders, requestBody);
    if (keycloakCreateUserResponse.status !== 200) {
        return {
            data: null, 
            error: customError.unknownError(
                keycloakCreateUserResponse.status,
                keycloakCreateUserResponse?.responseData?.error, 
                keycloakCreateUserResponse?.responseData?.error_description)
            }
    }

    return {data: keycloakCreateUserResponse, error: null};
}

const resetKeycloakUserPassword = async (accessToken, keycloadUserId, newPassword) => {
    let requestBody = {
        type: 'password',
        temporary: false,
        value: newPassword,
    };
    let requestHeaders = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
    }
    
    let keycloadResetPasswordUrl = `${process.env.KEYCLOAK_API_DOMAIN}${constants.KEYCLOAK_ENDPOINT.USERS}/${keycloadUserId}/reset-password`;

    let keycloakResetPasswordResponse = await common.axiosRequest(keycloadResetPasswordUrl, 'PUT', requestHeaders, requestBody);
    if (keycloakResetPasswordResponse.status !== 200) {
        return {
            data: null, 
            error: customError.unknownError(
                keycloakResetPasswordResponse.status,
                keycloakResetPasswordResponse?.responseData?.error, 
                keycloakResetPasswordResponse?.responseData?.error_description)
            }
    }

    return {data: keycloakResetPasswordResponse, error: null};
}

module.exports = {
    getKeycloakUsers,
    createKeycloakUser,
    resetKeycloakUserPassword,
    generateKeycloakAccessToken,
}
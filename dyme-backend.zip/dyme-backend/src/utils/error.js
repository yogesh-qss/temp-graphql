const badRequestError = (error, errorDescription=null) => {
    return {
        status: 400,
        message: 'BAD_REQUEST',
        error: { error, errorDescription }
    }
}

const authenticationError = (error, errorDescription=null) => {
    return {
        status: 401,
        message: 'UNAUTHENTICATED',
        error: { error, errorDescription }
    }
}

const userValidationError = (error, errorDescription=null) => {
    return {
        status: 400,
        message: 'USER_VALIDATION_ERROR',
        error: { error, errorDescription }
    }
}

const authorizationError = (error, errorDescription=null) => {
    return {
        status: 403,
        message: 'UNAUTHORIZED',
        error: { error, errorDescription }
    }
}

const conflictError = (error, errorDescription=null) => {
    return {
        status: 409,
        message: 'CONFLICT',
        error: { error, errorDescription }
    }
}

const storageSpaceExceededError = (error, errorDescription=null) => {
    return {
        status: 413,
        message: 'STORAGE_SPACE_EXCEEDED',
        error: { error, errorDescription }
    }
}

const tooManyRequestError = (error, errorDescription=null) => {
    return {
        status: 429,
        message: 'TOO_MANY_REQUESTS',
        error: { error, errorDescription }
    }
}

const internalServerError = (error, errorDescription=null) => {
    return {
        status: 500,
        message: 'INTERNAL_SERVER_ERROR',
        error: { error, errorDescription }
    }
}

const badGatewayError = (error, errorDescription=null) => {
    return {
        status: 502,
        message: 'BAD_GATEWAY',
        error: { error, errorDescription }
    }
}

const serviceUnavailableError = (error, errorDescription=null) => {
    return {
        status: 503,
        message: 'SERVICE_UNAVAILABLE',
        error: { error, errorDescription }
    }
}

const unknownError = (statusCode, error, errorDescription=null) => {
    switch(statusCode) {
        case 400:
            return this.badRequestError(error, errorDescription)
        case 401:
            return authenticationError(error, errorDescription);
        case 403:
            return this.authorizationError(error, errorDescription);
        case 409:
            return this.conflictError(error, errorDescription);
        case 413:
            return this.storageSpaceExceededError(error, errorDescription);
        case 429:
            return this.tooManyRequestError(error, errorDescription);
        case 500:
            return this.internalServerError(error, errorDescription);
        case 502:
            return this.badGatewayError(error, errorDescription);
        case 503:
            return this.serviceUnavailableError(error, errorDescription);
        default:
            return {
                status: 500,
                message: 'UNKNOWN_ERROR',
                error: { error, errorDescription }
            }
    }
}

module.exports = {
    conflictError,
    unknownError,
    badRequestError,
    badGatewayError,
    authorizationError,
    userValidationError,
    authenticationError,
    internalServerError,
    tooManyRequestError,
    serviceUnavailableError,
    storageSpaceExceededError,
}
const axios = require('axios');
const crypto = require('crypto');

global.encrypt = (text) => {
    let cipher = crypto.createCipheriv(
        process.env.ALGORITHM, 
        process.env.PRIVATE_KEY, 
        process.env.IV
    );
    return cipher.update(text, "utf8", "hex") + cipher.final("hex");
}

global.decrypt = (text) => {
    let decipher = crypto.createDecipheriv(
        process.env.ALGORITHM, 
        process.env.PRIVATE_KEY, 
        process.env.IV
    );
    return decipher.update(text, "hex", "utf8") + decipher.final("utf8");
}

module.exports = {
    axiosRequest: async (requestUrl, requestMethod, requestHeader, requestBody) => {
        try {
            let responseData;
            let requestObject = {
                url: requestUrl,
                headers: requestHeader,
                method: requestMethod.toLowerCase(),
            }
            requestObject = (requestMethod.toLowerCase() === 'get') ? {...requestObject, params: requestBody} : {...requestObject, data: requestBody}
            responseData = await axios(requestObject);

            responseData = responseData.data;
            return {requestSuccessful: true, responseData, status: 200};
        } catch({response}) {
            return response 
                ? {requestSuccessful: true, responseData: response.data, status: response.status} 
                : {requestSuccessful: false, responseData: {error: 'Axios request failed', errorDescription: null}, status: 500};
        }
    },

    generateCode: (requestedLength) => {
        if(process.env.MASTER_CODE_ENABLED) {
            return process.env.MASTER_CODE;
        } else {
            const characters = '1234567890';
            const length = typeof requestedLength != 'undefined' ? requestedLength : 4;
            let randomValue = '';
            for (let i = 0; i < length; i++) {
                const value = Math.floor(Math.random() * characters.length);
                randomValue += characters.substring(value, value + 1).toUpperCase();
            }
            return randomValue;
        }
    }
}
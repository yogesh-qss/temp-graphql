const aws = require('aws-sdk');

const ses = new aws.SES({
    region: process.env.SES_REGION,
    accessKeyId: process.env.SES_ACCESS_KEY_ID,
    secretAccessKey: process.env.SES_SECRET_ACCESS_KEY,
});

const sendEmail = async (toAddresses, subject, htmlBody, ccAddresses=undefined, bccAddresses=undefined) => {
    ses.sendEmail({
        Source: process.env.SES_FROM_EMAIL_ID,
        Destination: { 
            ToAddresses: toAddresses,
            CcAddresses: ccAddresses,
            BccAddresses: bccAddresses
        },
        Message: {
            Subject: { Data: subject, },
            Body: {
                Html: { 
                    Charset: 'utf-8',
                    Data: htmlBody,
                },
            }
        }
    }, (error, data) => {
        if (error) return {data: null, error}
        console.log('//////////////////////////////////////')
        console.log('EMAIL_SENT: ', data)
        console.log('//////////////////////////////////////')
        return {data, error: null}
    })
}

module.exports = {
    sendEmail,
}
module.exports = {
    KEYCLOAK_ENDPOINT: {
        USERS: '/users',                                                                    // Other uses (Note: There are different keys with same value to increase readability of the code)
        ADD_USER: '/users',                                                             // Method = POST
        GET_USERS: '/users',                                                            // Method = GET
        AUTH: '/protocol/openid-connect/token',
    },
    STATUS: {
        INACTIVE: 0,
        ACTIVE: 1,
        VERIFICATION_PENDING: 2,
    },
    USER_IDENTITY: {
        ENTITY: 'entity',
        INDIVIDUAL: 'individual',
    },
    DEFAULT_ROLES: {
        ADMIN: 1,
        USER: 2,
    },
    SMS_TYPES: {
        TRANSACTIONAL: 'Transactional',
    }
}